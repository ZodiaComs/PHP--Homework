<html>

    <head>
        <title> php homework </title>
    </head>

    <body>
        <?php
            echo "hello world";
            echo "<br>";
            echo "<b> hello php </b>";
            echo "<br>";

            $a = 10;
            $b = 20;

            if($a < $b)
            {
                echo "that's that and this is this.";
            }
        ?>
    </body>

</html>